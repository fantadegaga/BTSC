# BTSC — Technical & Engineering Maintenance Website

Prototype website Afaan Oromoo, responsive (bilbila Android fi kompiitara), HTML/CSS/JavaScript qofa.

## Faayilota
- `index.html` — caasaa fuula website
- `style.css` — bifa, halluu fi mobile responsive layout
- `script.js` — menu mobile, machine search/filter, demo maintenance form fi print
- `README.md` — qajeelfama

## Akkaataa local irratti ilaaluu
`index.html` browser (Chrome/Edge) keessatti bani.

## Maxxansuu GitHub Pages irratti
1. GitHub account seeni ykn account uumi: https://github.com/
2. **New repository** filadhu.
3. Repository name: `btsc-technical-maintenance` (ykn maqaa ati barbaaddu).
4. Public filadhu, README filannoo yoo barbaadde, Create repository tuqi.
5. Repository keessatti **Add file → Upload files** filadhu.
6. Faayilota `index.html`, `style.css`, `script.js`, fi `README.md` upload godhi; **Commit changes** tuqi.
7. **Settings → Pages** seeni.
8. **Build and deployment → Source** keessatti `Deploy from a branch` filadhu.
9. Branch `main`, folder `/(root)` filadhu; **Save** tuqi.
10. Daqqiiqaa muraasa eegii Settings → Pages keessatti **Visit site** tuqi.

GitHub Docs: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Hubachiisa barbaachisaa
- Kun prototype static dha; login, database, stock dhugaa, maintenance record server irratti kuusuu hin qabu.
- Lakkoofsi machines 159/46/113 fi maqaawwan table keessatti mul'atan fakkeenya jalqabaa qofa; osoo hin maxxansin ragaa sirrii yeroo ammaa waliin mirkaneessi.
- GitHub Pages irratti website maxxanfamu uummataaf mul'achuu danda'a. Odeeffannoo iccitii dhaabbatichaa, passwords, lakkoofsa bilbilaa dhuunfaa ykn faayilota confidential hin upload godhin.
- Logo BTSC hayyamame yoo jiraate, itti dabali. Maqaa model, stock, machine statuses fi contact details mirkaneessi.
- Form galmee maintenance kun demo qofa; data server/database irratti hin kuusu.
