const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle?.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded', 'false');
}));

const machineSearch = document.getElementById('machineSearch');
const statusFilter = document.getElementById('statusFilter');
function filterMachines() {
  const query = (machineSearch.value || '').toLowerCase().trim();
  const status = statusFilter.value;
  document.querySelectorAll('#machineTable tbody tr').forEach(row => {
    const matchesText = row.textContent.toLowerCase().includes(query);
    const matchesStatus = status === 'all' || row.textContent.includes(status);
    row.hidden = !(matchesText && matchesStatus);
  });
}
machineSearch?.addEventListener('input', filterMachines);
statusFilter?.addEventListener('change', filterMachines);

document.getElementById('maintenanceForm')?.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const message = `Galmee fakkeenyaa: ${data.get('machine')} — ${data.get('type')}, ${data.get('date')}. Haala: ${data.get('status')}.`;
  document.getElementById('formMessage').textContent = message + ' Hubadhu: odeeffannoon kun server/database irratti hin kuufamu.';
  event.currentTarget.reset();
});
document.getElementById('printBtn')?.addEventListener('click', () => window.print());
